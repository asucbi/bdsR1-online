# load packages ----------------------------------------------------------------

library(tidyverse)
library(rvest)
library(glue)


# question 10: generate the list of urls to be scraped ---------------------------------

prefix <- 
suffix <- 

numbers <- 
urls <- 


# use map_dfr() to map over all urls and output a data frame --------------


# use write_csv() to write out data frame ---------------------------------
